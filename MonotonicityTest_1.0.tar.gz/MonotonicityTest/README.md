# MonotonicityTest

## TODO

-   [ ] Write examples and descriptions
-   [x] More verbose tests
-   [x] Change parlapply to work with windows
-   [ ] Add plots
