## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib MonotonicityTest, .registration = TRUE
## usethis namespace: end
NULL
